<?php

namespace Vault\Exceptions;

/**
 * Class ClassNotFoundException
 *
 * @package Vault\Exception
 */
class ClassNotFoundException extends \RuntimeException
{
}