<?php

namespace Yandex\Allure\Adapter\Model;

/**
 * Marker interface
 * @package Yandex\Allure\Adapter\Model
 */
interface Entity
{
}
