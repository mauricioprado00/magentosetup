<?php

namespace Laminas\I18n\Exception;

class ParseException extends RuntimeException implements ExceptionInterface
{
}
