<?php

namespace Laminas\I18n\Exception;

interface ExceptionInterface
{
}
