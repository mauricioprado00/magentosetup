<?php

declare(strict_types=1);

namespace Laminas\Filter;

/**
 * @deprecated Use AllowList
 */
class Whitelist extends AllowList
{
}
