<?php

namespace Laminas\Validator\Exception;

class ExtensionNotLoadedException extends RuntimeException
{
}
