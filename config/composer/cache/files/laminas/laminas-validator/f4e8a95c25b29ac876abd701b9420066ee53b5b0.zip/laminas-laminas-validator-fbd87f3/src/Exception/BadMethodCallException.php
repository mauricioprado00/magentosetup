<?php

namespace Laminas\Validator\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
