<?php

declare(strict_types=1);

namespace Laminas\Stdlib;

class Response extends Message implements ResponseInterface
{
    // generic response implementation
}
