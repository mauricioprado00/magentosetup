<?php

declare(strict_types=1);

namespace Laminas\Stdlib\Exception;

/**
 * Domain exception
 */
class DomainException extends \DomainException implements ExceptionInterface
{
}
