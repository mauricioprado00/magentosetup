<?php

declare(strict_types=1);

namespace Laminas\Stdlib\Exception;

/**
 * Exception marker interface
 */
interface ExceptionInterface
{
}
