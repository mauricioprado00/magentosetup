<?php

namespace Laminas\Http\Header\Exception;

use Laminas\Http\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements
    ExceptionInterface
{
}
