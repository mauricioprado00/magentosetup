<?php

namespace Laminas\Http\Exception;

class RuntimeException extends \RuntimeException implements
    ExceptionInterface
{
}
