<?php

namespace Laminas\Http\Client\Adapter\Exception;

use Laminas\Http\Client\Exception\ExceptionInterface as HttpClientException;

interface ExceptionInterface extends HttpClientException
{
}
