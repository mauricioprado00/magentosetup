<?php

namespace Laminas\Http\Client\Exception;

use Laminas\Http\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements
    ExceptionInterface
{
}
