<?php

namespace Laminas\Http\Header\Exception;

use Laminas\Http\Exception;

class RuntimeException extends Exception\RuntimeException implements
    ExceptionInterface
{
}
