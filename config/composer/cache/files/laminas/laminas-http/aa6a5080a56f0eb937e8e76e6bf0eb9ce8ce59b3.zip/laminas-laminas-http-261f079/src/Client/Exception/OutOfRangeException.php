<?php

namespace Laminas\Http\Client\Exception;

use Laminas\Http\Exception;

class OutOfRangeException extends Exception\OutOfRangeException implements
    ExceptionInterface
{
}
