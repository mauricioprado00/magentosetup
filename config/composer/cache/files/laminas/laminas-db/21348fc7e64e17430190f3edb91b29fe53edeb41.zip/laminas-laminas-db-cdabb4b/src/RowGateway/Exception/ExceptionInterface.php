<?php

namespace Laminas\Db\RowGateway\Exception;

use Laminas\Db\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
