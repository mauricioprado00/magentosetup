<?php

namespace Laminas\Db\TableGateway\Exception;

use Laminas\Db\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements ExceptionInterface
{
}
