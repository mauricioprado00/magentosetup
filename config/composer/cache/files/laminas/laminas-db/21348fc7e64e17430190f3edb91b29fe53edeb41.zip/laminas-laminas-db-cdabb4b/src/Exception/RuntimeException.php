<?php

namespace Laminas\Db\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
