<?php

namespace Laminas\Db\Sql\Ddl\Column;

class Binary extends AbstractLengthColumn
{
    /** @var string */
    protected $type = 'BINARY';
}
