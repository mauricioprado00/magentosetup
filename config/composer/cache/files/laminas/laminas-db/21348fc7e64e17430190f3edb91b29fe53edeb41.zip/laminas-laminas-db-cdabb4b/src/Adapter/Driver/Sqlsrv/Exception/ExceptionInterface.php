<?php

namespace Laminas\Db\Adapter\Driver\Sqlsrv\Exception;

use Laminas\Db\Adapter\Exception;

interface ExceptionInterface extends Exception\ExceptionInterface
{
}
