<?php

namespace Laminas\Db\Sql\Ddl;

use Laminas\Db\Sql\SqlInterface as BaseSqlInterface;

interface SqlInterface extends BaseSqlInterface
{
}
