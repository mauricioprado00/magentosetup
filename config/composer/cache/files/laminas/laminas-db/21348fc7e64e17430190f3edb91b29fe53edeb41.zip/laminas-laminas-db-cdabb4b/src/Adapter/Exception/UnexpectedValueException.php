<?php

namespace Laminas\Db\Adapter\Exception;

use Laminas\Db\Exception;

class UnexpectedValueException extends Exception\UnexpectedValueException implements ExceptionInterface
{
}
