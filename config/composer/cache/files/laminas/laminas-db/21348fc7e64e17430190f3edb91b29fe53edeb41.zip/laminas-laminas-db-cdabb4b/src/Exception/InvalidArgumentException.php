<?php

namespace Laminas\Db\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
