<?php

namespace Laminas\Db\ResultSet\Exception;

use Laminas\Db\Exception;

class InvalidArgumentException extends Exception\InvalidArgumentException implements ExceptionInterface
{
}
