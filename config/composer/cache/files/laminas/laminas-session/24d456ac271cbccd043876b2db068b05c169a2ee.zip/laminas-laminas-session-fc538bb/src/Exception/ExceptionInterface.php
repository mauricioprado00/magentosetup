<?php

namespace Laminas\Session\Exception;

/**
 * Laminas\Session\Exception
 */
interface ExceptionInterface
{
}
