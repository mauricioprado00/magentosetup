<?php

namespace Laminas\Captcha\Exception;

/**
 * Exception for Laminas\Form component.
 */
class ImageNotLoadableException extends RuntimeException
{
}
