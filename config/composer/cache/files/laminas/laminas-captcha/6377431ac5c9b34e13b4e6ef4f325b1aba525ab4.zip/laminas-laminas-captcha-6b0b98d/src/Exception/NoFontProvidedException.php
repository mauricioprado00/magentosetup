<?php

namespace Laminas\Captcha\Exception;

/**
 * Exception for Laminas\Form component.
 */
class NoFontProvidedException extends InvalidArgumentException
{
}
