<?php

namespace Laminas\Captcha\Exception;

/**
 * Exception for Laminas\Form component.
 */
class ExtensionNotLoadedException extends RuntimeException
{
}
