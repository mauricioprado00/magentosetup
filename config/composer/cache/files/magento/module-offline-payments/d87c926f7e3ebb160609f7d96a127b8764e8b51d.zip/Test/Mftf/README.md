# Offline Payments Functional Tests

The Functional Test Module for **Magento Offline Payments** module.
