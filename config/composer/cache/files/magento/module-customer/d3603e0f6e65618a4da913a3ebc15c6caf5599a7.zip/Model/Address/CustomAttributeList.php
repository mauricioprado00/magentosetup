<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Customer\Model\Address;

class CustomAttributeList implements CustomAttributeListInterface
{
    /**
     * {@inheritdoc}
     */
    public function getAttributes()
    {
        return [];
    }
}
