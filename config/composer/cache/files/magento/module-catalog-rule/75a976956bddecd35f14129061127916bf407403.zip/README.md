Magento_CatalogRule module is responsible for one of the types of price rules in Magento. Catalog Rules are applied to products before they are added to the cart.
