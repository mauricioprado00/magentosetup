The Store module provides one of the basic and major features of a content management system for e-commerce web
sites by creating and managing a store for the customers to conduct online-shopping. Stores can be combined in groups,
and are linked to a specific website. All store related configurations (currency, locale, scope etc.), management and
storage maintenance are covered under this module.