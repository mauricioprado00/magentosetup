# Message Queue Functional Tests

The Functional Test Module for **Magento Message Queue** module.
