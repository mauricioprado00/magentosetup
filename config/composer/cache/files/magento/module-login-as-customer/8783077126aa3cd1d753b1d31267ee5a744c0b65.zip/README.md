# Magento_LoginAsCustomer module

The Magento_LoginAsCustomer module is responsible for ability to login into customer account using the admin panel.
