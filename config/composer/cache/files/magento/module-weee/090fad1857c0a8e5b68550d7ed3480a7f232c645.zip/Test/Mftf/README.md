# Weee Functional Tests

The Functional Test Module for **Magento Weee** module.
