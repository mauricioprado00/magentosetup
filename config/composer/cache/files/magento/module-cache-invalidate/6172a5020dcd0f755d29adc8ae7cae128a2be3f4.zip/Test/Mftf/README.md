# Cache Invalidate Functional Tests

The Functional Test Module for **Magento Cache Invalidate** module.
