Magento\Elasticsearch7 module allows to use Elastic search engine (v7) for product searching capabilities.
The module implements Magento\Search library interfaces.
