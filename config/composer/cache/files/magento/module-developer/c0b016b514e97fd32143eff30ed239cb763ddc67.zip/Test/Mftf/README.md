# Developer Functional Tests

The Functional Test Module for **Magento Developer** module.
