# Downloadable Import Export Functional Tests

The Functional Test Module for **Magento Downloadable Import Export** module.
