# LoginAsCustomerPageCache module

The Magento_LoginAsCustomerPageCache module provides adaptation to PageCache functionality
