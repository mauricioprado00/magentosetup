The Sitemap module allows managing the Magento application sitemap and
[sitemap.xml](http://en.wikipedia.org/wiki/Sitemaps) for searching engines.