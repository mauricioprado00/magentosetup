# Magento_LoginAsCustomerSales module

The Magento_LoginAsCustomerAdminUi module provides UI for Admin Panel
