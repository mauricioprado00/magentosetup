<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Paypal\Controller\Adminhtml\Transparent;

/**
 * Class Response
 *
 * @package Magento\Paypal\Controller\Adminhtml\Transparent
 */
class Response extends \Magento\Paypal\Controller\Transparent\Response
{
}
