# Magento_LoginAsCustomerQuote module

The Magento_LoginAsCustomerQuote module is responsible for communication between Magento_LoginAsCustomer and shopping cart state.
