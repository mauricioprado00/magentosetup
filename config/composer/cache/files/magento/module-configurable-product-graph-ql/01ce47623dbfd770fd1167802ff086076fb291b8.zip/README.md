# ConfigurableProductGraphQl

**ConfigurableProductGraphQl** provides type and resolver information for the GraphQl module
to generate configurable product information.
