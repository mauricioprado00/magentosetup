# Inventory Configurable Product Admin Ui Functional Tests

The Functional Test Module for **Magento Inventory Configurable Product Admin Ui** module.
