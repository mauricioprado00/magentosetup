# Magento_LoginAsCustomerSales module

The Magento_LoginAsCustomerSales module is responsible for communication between Magento_LoginAsCustomer and order placement.
