# Inventory Catalog Admin Ui Functional Tests

The Functional Test Module for **Magento Inventory Catalog Admin Ui** module.
