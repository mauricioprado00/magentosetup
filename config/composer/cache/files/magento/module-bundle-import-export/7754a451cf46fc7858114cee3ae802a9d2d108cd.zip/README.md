Magento_BundleImportExport module implements Bundle products import/export functionality.
This module is designed to extend existing functionality of Magento_CatalogImportExport module by adding new product type.
