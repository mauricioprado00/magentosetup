# Payment Functional Tests

The Functional Test Module for **Magento Payment** module.
