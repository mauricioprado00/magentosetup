# Webapi

**Webapi** provides the framework for the application to expose REST and SOAP web services. It exposes an area for REST
and another area for SOAP services and routes requests based on the Webapi configuration. It also handles
deserialization of requests and serialization of responses. 
