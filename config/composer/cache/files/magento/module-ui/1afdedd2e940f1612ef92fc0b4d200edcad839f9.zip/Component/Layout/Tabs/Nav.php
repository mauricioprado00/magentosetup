<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Ui\Component\Layout\Tabs;

use Magento\Framework\View\Element\Template;

/**
 * Class Nav
 */
class Nav extends Template
{
    //
}
