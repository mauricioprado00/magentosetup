# Catalog Inventory Functional Tests

The Functional Test Module for **Magento Catalog Inventory** module.
